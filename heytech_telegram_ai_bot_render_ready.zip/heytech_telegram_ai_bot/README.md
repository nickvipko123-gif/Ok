# HeyTech Telegram AI Code Bot

Telegram bot for AI chat/code generation using an OpenAI-compatible API gateway. Includes model selection, text/code file uploads, ZIP project text extraction, short in-memory conversation history, and long-response file delivery.

## 1. Requirements
- Python 3.10+
- Telegram bot token from `@BotFather`
- HeyTech API token and the **exact API Base URL** from your HeyTech account/docs

## 2. Configure
```bash
cp .env.example .env
```
Edit `.env`:
- `TELEGRAM_BOT_TOKEN`
- `HEYTECH_API_KEY`
- `HEYTECH_BASE_URL`
- Optional `DEFAULT_MODEL`
- Recommended: `ALLOWED_TELEGRAM_IDS` set to your numeric Telegram user ID.

The template defaults to `https://heytech.vn/v1`, but that URL is only a placeholder assumption. Verify the actual API host and compatibility with HeyTech. The code expects:
- `GET {BASE_URL}/models` returning a `data` array with `id` (or `name`) values
- `POST {BASE_URL}/chat/completions` accepting OpenAI-style `model` and `messages`

If HeyTech uses different paths or a different request/response schema, update `get_models()` and `chat()` in `bot.py`.

## 3. Run
```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
python bot.py
```

## 4. Commands
- `/start` — start
- `/help` — help
- `/models` — fetch and choose model
- `/model` — show selected model
- `/reset` — clear chat history and uploaded-file context

Send normal text to chat. Send a `.zip` to extract supported text/code files into context, then ask your question. Supported text/code extensions include PHP, Python, JS/TS, HTML, CSS, SQL, JSON, Markdown, YAML and more. Common bulky folders such as `node_modules`, `vendor`, `.git`, `dist`, and `build` are skipped.

## 5. Docker
```bash
docker compose up -d --build
docker compose logs -f
```

## Security and limitations
- Never commit `.env` or share API tokens.
- Restrict `ALLOWED_TELEGRAM_IDS` for a private bot.
- File context and chat history are stored in memory only and disappear when the bot restarts.
- ZIP contents are treated as text context, not executed.
- This starter does not execute generated code or automatically modify/deploy a project.
- Telegram and provider rate limits/billing still apply.


## Deploy on Render (Background Worker 24/7)

This repository includes `render.yaml` as a Render Blueprint. It defines a Docker Background Worker, not a Cron Job. The bot uses Telegram long polling, so it must stay running.

1. Push the entire project folder to a GitHub repository. Do not upload `.env` or API tokens.
2. In Render, choose **New → Blueprint** and connect the repository containing `render.yaml`.
3. Review the `heytech-ai-telegram` service and choose the paid `starter` worker plan (Render plan names/prices can change).
4. Enter the secret values when prompted:
   - `TELEGRAM_BOT_TOKEN`: token from `@BotFather`
   - `HEYTECH_API_KEY`: HeyTech API token
   - `HEYTECH_BASE_URL`: exact API base URL documented by HeyTech
   - `DEFAULT_MODEL`: exact supported model ID, or leave empty and use `/models` if supported
   - `ALLOWED_TELEGRAM_IDS`: your numeric Telegram user ID; recommended. Do not leave blank for a private bot.
5. Deploy, then open the service's **Logs**. Expected startup line: `HeyTech AI Code Bot is running…`
6. Open your Telegram bot and send `/start`, then `/models`.

### Important API compatibility check

The code currently assumes an OpenAI-compatible API:
- `GET {HEYTECH_BASE_URL}/models`
- `POST {HEYTECH_BASE_URL}/chat/completions`
- bearer token authentication

The default URL previously shown in `.env.example` is a placeholder assumption, not verified HeyTech documentation. Use the actual endpoint and request format provided in your HeyTech dashboard/docs. If HeyTech uses another API schema, adapt `get_models()` and `chat()` in `bot.py`.

### 24/7 and Cron

Do not use a Cron Job to keep this polling bot alive. Cron jobs run a command on a schedule and exit; a Background Worker is the correct service type for continuous polling. Do not create multiple worker instances with the same Telegram token, or polling conflicts can occur.

### Cost

A continuously running paid worker incurs compute charges. Check current Render pricing before deploying: https://render.com/pricing
